# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = 'e8298265632c1b4f478c1f3fdd7c08affeb4624922ab8742e885c9e6dc9ca02d6b273ad199435cc28f7a138a16e7bad09a11fa3b4312563a82a5675cef449641'
